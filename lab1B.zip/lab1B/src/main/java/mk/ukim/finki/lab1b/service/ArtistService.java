package mk.ukim.finki.lab1b.service;

import mk.ukim.finki.lab1b.model.Artist;

import java.util.List;

public interface ArtistService {
    List<Artist> listArtists();

    Artist findById(Long id);
}
