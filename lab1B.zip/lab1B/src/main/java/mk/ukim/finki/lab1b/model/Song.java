package mk.ukim.finki.lab1b.model;

import lombok.Data;
import lombok.Getter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Data
public class Song {

    private Long id;
    private String trackId;
    private String title;
    private String genre;
    private int releaseYear;
    private List<Artist> performers;
    private Album album;

    public Song(String trackId, String title, String genre, int releaseYear, Long id, Album album) {
        this.trackId = trackId;
        this.title = title;
        this.genre = genre;
        this.releaseYear = releaseYear;
        this.id = id;
        this.album = album;

        performers = new ArrayList<>();
    }

    public Song(String title, String genre, int releaseYear, Album album){
        this.title = title;
        this.genre = genre;
        this.releaseYear = releaseYear;
        this.album = album;
    }

    public void addPerformer(Artist performer) {
        performers.add(performer);
    }

}
