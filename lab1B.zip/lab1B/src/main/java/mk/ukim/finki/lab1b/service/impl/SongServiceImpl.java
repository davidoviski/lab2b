package mk.ukim.finki.lab1b.service.impl;

import mk.ukim.finki.lab1b.model.Album;
import mk.ukim.finki.lab1b.model.Artist;
import mk.ukim.finki.lab1b.model.Song;
import mk.ukim.finki.lab1b.repository.SongRepository;
import mk.ukim.finki.lab1b.service.SongService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.Random;

@Service
public class SongServiceImpl implements SongService{

    private final SongRepository songRepository;

    public SongServiceImpl(SongRepository songRepository) {
        this.songRepository = songRepository;
    }

    @Override
    public List<Song> listSongs() {
        return songRepository.findAll();
    }

    @Override
    public Artist addArtistToSong(Artist artist, Song song) {
        return songRepository.addArtistToSong(artist, song);
    }

    @Override
    public Song findByTrackId(String trackId) {
        return songRepository.findByTrackId(trackId);
    }

    @Override
    public Song findSongByName(String name) {
        return songRepository.findSongByName(name);
    }

    @Override
    public void deleteId(Long id) {
        songRepository.deleteId(id);
    }

    @Override
    public Song findById(Long id) {
        return songRepository.findById(id);
    }

    @Override
    public Optional<Song> save(String title, String genre, Integer releaseYear, Album album, Long randomId) {

        return songRepository.save(title, genre, releaseYear, album, randomId);
    }

    @Override
    public Long getRandomId(){
        return songRepository.getRandomId();
    }

}
