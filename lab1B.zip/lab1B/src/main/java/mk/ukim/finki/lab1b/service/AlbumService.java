package mk.ukim.finki.lab1b.service;

import mk.ukim.finki.lab1b.model.Album;

import java.util.List;
import java.util.Optional;

public interface AlbumService {
    List<Album> findAll();

    Optional<Album> findAlbumById(Long albumId);
}
