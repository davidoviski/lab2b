package mk.ukim.finki.lab1b.web.controller;

import mk.ukim.finki.lab1b.model.Artist;
import mk.ukim.finki.lab1b.service.ArtistService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class ArtistController {

    private final ArtistService artistService;

    @Autowired
    public ArtistController(ArtistService artistService){
        this.artistService = artistService;
    }

    @GetMapping("/artists")
    public String listArtists(Model model){
        List<Artist> artists = artistService.listArtists();
        model.addAttribute("artists", artists);
        return "artistsList";
    }

    @PostMapping("/artists")
    public String selectSong(@RequestParam(name = "songRadio", required = false, defaultValue = "-") String trackId, Model model){
        List<Artist> artists = this.artistService.listArtists();
        model.addAttribute("trackId", trackId);
        model.addAttribute("artists", artists);
        return "artistsList";
    }
}
