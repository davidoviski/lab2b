package mk.ukim.finki.lab1b.bootstrap;

import jakarta.annotation.PostConstruct;
import mk.ukim.finki.lab1b.model.Album;
import mk.ukim.finki.lab1b.model.Artist;
import mk.ukim.finki.lab1b.model.Song;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class DataHolder {

    public static List<Artist> artists = new ArrayList<>();
    public static List<Song> songList = new ArrayList<>();

    public static List<Album> albumList = new ArrayList<>();

    @PostConstruct
    public void init() {
        artists.add(new Artist(123456789L, "Celine", "Dion", "Céline Marie Claudette Dion CC OQ is a Canadian singer. Referred to as the Queen of Power Ballads, she is noted for her powerful and technically skilled vocals."));
        artists.add(new Artist(112233445L, "Billie", "Eilish", "Billie Eilish Pirate Baird O'Connell is an American singer and songwriter. She first gained public attention in 2015 with her debut single \"Ocean Eyes\", written and produced by her brother Finneas O'Connell, with whom she collaborates on music and live shows."));
        artists.add(new Artist(121243657L, "Jennifer", "Lopez", "Jennifer Lynn Affleck, also known by her nickname J.Lo, is an American actress, singer, dancer and businesswoman. Lopez is regarded as one of the most influential Latin entertainers of her time"));
        artists.add(new Artist(254662890L, "Ed", "Sheeran", "Edward Christopher Sheeran MBE is an English singer-songwriter. Born in Halifax, West Yorkshire, and raised in Framlingham, Suffolk, he began writing songs around the age of eleven."));
        artists.add(new Artist(432257538L, "Taylor", "Swift", "Taylor Alison Swift is an American singer-songwriter. Known for her biographical songwriting, artistic reinventions, and cultural impact, Swift is a leading figure in popular music"));

        albumList.add(new Album(111L, "Album1", "Rock", "2002"));
        albumList.add(new Album(222L, "Album2", "Folk", "2001"));
        albumList.add(new Album(333L, "Album3", "Pop", "1993"));
        albumList.add(new Album(444L, "Album4", "Metal", "2017"));
        albumList.add(new Album(555L, "Album5", "Jazz", "1998"));

        songList.add(new Song( "Love", "The Power Of Love", "Country/Bluegrass", 1993, 123L, albumList.get(0)));
        songList.add(new Song( "HTE", "Happier Than Ever", "Rock/Pop", 2024, 345L, albumList.get(1)));
        songList.add(new Song( "Fun", "Ain't It Funny", "Blues", 2001, 567L, albumList.get(2)));
        songList.add(new Song( "Duet", "Perfect Duet", "Folk/Roots", 2017, 789L, albumList.get(3)));
        songList.add(new Song( "Summer", "Cruel Summer", "Rock", 2019, 901L, albumList.get(4)));



    }

}
