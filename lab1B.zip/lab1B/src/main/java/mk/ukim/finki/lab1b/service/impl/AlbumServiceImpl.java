package mk.ukim.finki.lab1b.service.impl;

import mk.ukim.finki.lab1b.model.Album;
import mk.ukim.finki.lab1b.repository.AlbumRepository;
import mk.ukim.finki.lab1b.service.AlbumService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AlbumServiceImpl implements AlbumService {

    private final AlbumRepository albumRepository;

    public AlbumServiceImpl(AlbumRepository albumRepository) {
        this.albumRepository = albumRepository;
    }

    @Override
    public List<Album> findAll() {
        return albumRepository.findAll();
    }

    @Override
    public Optional<Album> findAlbumById(Long albumId){
        return albumRepository.findAlbumById(albumId);
    }
}
