package mk.ukim.finki.lab1b.service;

import mk.ukim.finki.lab1b.model.Album;
import mk.ukim.finki.lab1b.model.Artist;
import mk.ukim.finki.lab1b.model.Song;

import java.util.List;
import java.util.Optional;

public interface SongService {
    List<Song> listSongs();
    Artist addArtistToSong(Artist artist, Song song);
    Song findByTrackId(String trackId);

    Song findSongByName(String name);
    void deleteId(Long id);

    Song findById(Long id);

    Optional<Song> save(String title, String genre, Integer releaseYear, Album album, Long randomId);

    Long getRandomId();


}
