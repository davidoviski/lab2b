package mk.ukim.finki.lab1b.repository;

import lombok.Data;
import mk.ukim.finki.lab1b.bootstrap.DataHolder;
import mk.ukim.finki.lab1b.model.Album;
import mk.ukim.finki.lab1b.model.Artist;
import mk.ukim.finki.lab1b.model.Song;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Random;

@Repository
public class SongRepository {

    public List<Song> findAll() {
        return DataHolder.songList;
    }

    public Song findByTrackId(String trackId) {
        return DataHolder.songList.stream().filter(s -> s.getTrackId().equals(trackId)).findFirst().orElse(null);
    }

    public Artist addArtistToSong(Artist artist, Song song) {
        for (Song s : DataHolder.songList) {
            if (s.getTrackId().equals(song.getTrackId())) {
                s.addPerformer(artist);
                return artist;
            }
        }
        return null;
    }

    public Song findSongByName(String name){
        return DataHolder.songList.stream().filter(song -> song.getTitle().toLowerCase().contains(name.toLowerCase())).findFirst().get();
    }

    public void deleteId(Long id){
        DataHolder.songList.removeIf(song -> Objects.equals(song.getId(), id));
    }


    public Song findById(Long id){
        return DataHolder.songList.stream().filter(song -> song.getId().equals(id)).findFirst().orElse(null);
    }

    public Optional<Song> save(String title, String genre, Integer releaseYear, Album album, Long randomId){
        Song song = new Song(title, genre, releaseYear, album);
        song.setId(getRandomId());
        DataHolder.songList.removeIf(s -> Objects.equals(s.getTitle(), title));
        DataHolder.songList.add(song);
        return Optional.of(song);
    }

    public Long getRandomId(){
        Random random = new Random();
        return 10000L + (long) (random.nextDouble() * (99999L - 10000L));
    }

}
