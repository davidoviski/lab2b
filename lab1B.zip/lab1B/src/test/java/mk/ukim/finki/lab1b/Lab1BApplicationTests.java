package mk.ukim.finki.lab1b;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab1BApplicationTests {

    @Test
    void contextLoads() {
    }

}
